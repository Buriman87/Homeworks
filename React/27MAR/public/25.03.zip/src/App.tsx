import React, { JSX } from "react";
import RoutesComponent from "./Routes/RoutesComponent";

const App: React.FC = (): JSX.Element => {
  return <RoutesComponent />;
};

export default App;
