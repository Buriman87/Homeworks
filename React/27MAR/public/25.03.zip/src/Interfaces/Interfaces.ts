export interface IUser {
  email: string;
  firstName: string;
  lastName: string;
}

export interface IFlat {
  city: string;
  street: string;
  number: number;
  price: number;
  areasize: number;
}
