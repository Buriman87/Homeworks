import React, { JSX } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import HomePageComponent from "../components/HomePageComponent";
import LoginPageComponent from "../components/LoginPageComponent";
import RegisterPageComponent from "../components/RegisterPageComponent";
import NotFoundPageComponent from "../components/NotFoundPageComponent";
import AddFlat from "../components/AddFlat";

const RoutesComponent: React.FC = (): JSX.Element => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePageComponent />} />
        <Route path="/login" element={<LoginPageComponent />} />
        <Route path="/register" element={<RegisterPageComponent />} />
        <Route path="/addflat" element={<AddFlat />} />
        <Route path="*" element={<NotFoundPageComponent />} />
      </Routes>
    </Router>
  );
};

export default RoutesComponent;
