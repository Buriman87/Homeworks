import React, { JSX, useEffect, useState } from "react";
import { collection, getDocs } from "firebase/firestore";
import { db } from "../firebase";
import { IFlat } from "../Interfaces/Interfaces";
import TableComponent from "./TableComponent";
import { Button } from "@mui/material";
import { useNavigate } from "react-router-dom";

const HomePageComponent: React.FC = (): JSX.Element => {
  const navigate = useNavigate();
  const [flats, setFlats] = useState<IFlat[]>([]);

  useEffect(() => {
    const getFlats = async () => {
      const querySnapshot = await getDocs(collection(db, "flats"));
      const data: IFlat[] = querySnapshot.docs.map((doc) => ({
        ...(doc.data() as IFlat),
      }));
      setFlats(data);
    };
    getFlats();
  }, []);

  if (flats?.length < 1) {
    return <p>Nu exista date</p>;
  }

  console.log(flats);

  return (
    <>
      <TableComponent flats={flats} />
      <br />
      <Button onClick={() => navigate("/addflat")}>Add Flat</Button>
    </>
  );
};

export default HomePageComponent;
