import React, { JSX } from "react";

const NotFoundPageComponent: React.FC = (): JSX.Element => {
  return <div>NotFoundPageComponent</div>;
};

export default NotFoundPageComponent;
